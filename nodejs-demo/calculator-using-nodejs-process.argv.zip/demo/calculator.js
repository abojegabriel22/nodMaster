// import yargs from "yargs"
// import { hideBin } from "yargs/helpers"

// const argv = yargs(hideBin(process.argv)).argv
// console.log(argv)

const [bin, bin2, numberOne, operation, numberTwo]= process.argv

console.log(process.argv)

console.log(typeof numberOne, operation, typeof numberTwo)
console.log(Number(numberOne)+Number(numberTwo))

//int
const numberOneFloat = parseFloat(numberOne)
const numberTwoFloat = parseFloat(numberTwo)
let result = 0



switch(operation){
    case "+":
        result = numberOneFloat + numberTwoFloat
        break

    case "-":
        result = numberOneFloat - numberTwoFloat
        break

    case "/":
        result = numberOneFloat / numberTwoFloat
        break

    case "*":
        result = numberOneFloat * numberTwoFloat
        break

    default:
        break
}


console.log(`Result is:  ${result}`)